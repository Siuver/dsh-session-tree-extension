/**
 * Pure projection between Harness SessionEvent logs and SessionTree nodes.
 * This module does not subscribe to a live Session or persistence service: the
 * host integration can feed it immutable `session.events` snapshots, while
 * preserving the Session log as the durable source of truth.
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
import type { TreeNode } from './types.ts';
/**
 * Compact result payload of one `tool/result` event: the call correlation,
 * the flattened result text, and the failure identity when the call errored.
 */
export interface ProjectedToolResult {
    callId: string;
    text: string;
    isError: boolean;
    error?: string;
}
/** Extract the call correlation and outcome of one `tool/result` event. */
export declare function toolResultOf(event: SessionEvent): ProjectedToolResult | undefined;
/**
 * Whether one `user/message` source marks harness-injected context instead of
 * a typed human prompt. Producers declare themselves through `source.kind`:
 * `'user'` is a direct human prompt, while `'plugin'` (skill content,
 * system-prompt snapshots, file-change notices, approvals, …) and
 * plugin-extended kinds (`'skill-catalog'`, …) are synthetic `agent.inject()`
 * context. Legacy logs carry a plain string source or none at all; both
 * predate injection bookkeeping and stay presented as human input.
 */
export declare function isInjectedUserSource(source: unknown): boolean;
/**
 * Whether one tree node records harness-injected context rather than a typed
 * human prompt (see {@link isInjectedUserSource}). Injected nodes stay in the
 * append-only projection — jump/fork re-select the model-visible surface from
 * the tree path, so dropping them would strip the skill catalog and
 * system-prompt snapshots from later model turns — but every user-facing
 * surface hides them.
 */
export declare function isInjectedUserNode(node: TreeNode): boolean;
/**
 * Fold one projected tool result into its tool-call node so the call and its
 * result read as a single tree entry (matching the model-visible pair). The
 * function is pure and idempotent: an already-merged node is returned as-is.
 */
export declare function attachToolResult(node: TreeNode, result: ProjectedToolResult, resultEventSeq: number | undefined): TreeNode;
/** Project the message-producing Harness events into an append-only tree. */
export declare function sessionEventsToTreeNodes(events: readonly SessionEvent[], initialParentId?: string | null): TreeNode[];
