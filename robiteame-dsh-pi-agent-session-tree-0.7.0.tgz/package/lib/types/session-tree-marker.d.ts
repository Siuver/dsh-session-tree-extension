/** Marker carried by official surface events written by stock-mode tree jumps. */
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
export interface SessionTreeRestoreMarker {
    readonly kind: 'cursor';
    readonly nodeId: string | null;
}
/**
 * Read the plugin marker from an event's JSON data. Native Harness events
 * never carry this key, so its presence is unambiguous.
 */
export declare function sessionTreeMarkerOf(event: SessionEvent): SessionTreeRestoreMarker | undefined;
/** Whether one event is a synthetic cursor rewrite rather than conversation content. */
export declare function isSessionTreeRestoreEvent(event: SessionEvent): boolean;
