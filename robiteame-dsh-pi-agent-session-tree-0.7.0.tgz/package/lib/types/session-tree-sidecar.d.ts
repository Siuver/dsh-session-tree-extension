/**
 * Plugin-owned durable sidecar for SessionTree projections.
 *
 * The stock DeepSeek-Harness session log does not recognize `session-tree/*`
 * events, so branch names, cursor, selection, and explicit snapshot state
 * cannot live inside `session.jsonl.zstd` without patching the harness. This
 * module keeps one small JSON artifact per session under the DSH home instead
 * and replays only native events after the stored watermark on resume.
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { SessionTree } from './session-tree.ts';
/** Synchronous sidecar store used by host-only session-tree plugins. */
export declare class SessionTreeSidecar {
    readonly root: string;
    constructor(root?: string);
    /** Read and validate the latest snapshot for one session. */
    load(sessionId: SessionId): SessionTree | undefined;
    /**
     * Atomically persist one tree. I/O errors are deliberately contained:
     * the native Session log remains the source of truth and can rebuild a
     * linear projection even when the sidecar directory is unavailable.
     */
    save(sessionId: SessionId, tree: SessionTree): boolean;
}
export declare function getSessionTreeSidecar(): SessionTreeSidecar;
/** Replace the active sidecar, primarily for isolated tests. */
export declare function setSessionTreeSidecar(sidecar: SessionTreeSidecar): void;
/** Persist one tree without coupling callers to the active store selection. */
export declare function persistSessionTree(tree: SessionTree): boolean;
