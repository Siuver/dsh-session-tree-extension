/**
 * Append-only multi-branch session tree. One tree owns one sessionId; the
 * store holds many trees side by side. All mutations are additions: a node
 * is never edited or removed after creation, and navigation only moves the
 * cursor, so every history branch survives (PI-Agent SessionTree semantics:
 * append-only entries, leaf-pointer branching, root-to-leaf message paths).
 *
 * @module @robiteame/dsh-pi-agent-session-tree/session-tree
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { BranchView, JsonValue, JumpView, ContentPart, LlmMessage, SessionTreeSessionInfo, SessionTreeSnapshot, SessionTreeView, TreeEntryType, TreeNode, SessionTreeLogEntry, TreeResult } from './types.ts';
/** One stored node plus the internal cursor bookkeeping. */
export declare class SessionTree {
    readonly sessionId: SessionId;
    private readonly nodesById;
    private cursorId;
    private selectedNodeId;
    private activeBranchName;
    private readonly branchHeads;
    private syncedSessionEventSeq;
    /**
     * Create an empty tree, or restore one from a versioned snapshot.
     * @param sessionId - owning session identity.
     * @param snapshot - optional durable snapshot to restore.
     * @throws Error when the snapshot is malformed (version, ownership, cursor).
     */
    constructor(sessionId: SessionId, snapshot?: unknown);
    /** Mint a node id guaranteed absent from this tree (collision-safe). */
    private mintNodeId;
    /** @returns the current cursor node id, or null before the first append. */
    get cursor(): string | null;
    /** Explicit node bound to context-aware UI commands. */
    get selectedNode(): string | null;
    /** Bind /fork and /clone to an existing node without changing cursor semantics. */
    select(nodeId: string): TreeResult<{
        nodeId: string;
    }>;
    /** @returns the branch label the next append joins. */
    get activeBranch(): string;
    /**
     * Append one new node as a child of the cursor. The cursor's parent chain
     * is never touched; the new node joins the active branch unless one is
     * named. Historical nodes stay byte-identical.
     * @param message - standard LLM message to carry.
     * @param options - optional branch override, summary, and JSON extras.
     * @returns the created node, or a standard error for invalid input.
     */
    /** Capture mutable projection state so an external durable write can commit atomically. */
    checkpoint(): SessionTreeSnapshot;
    /** Roll back to a previously captured checkpoint after a durable append fails. */
    rollback(snapshot: SessionTreeSnapshot): TreeResult<void>;
    append(message: LlmMessage, options?: {
        branch?: string;
        summary?: string;
        content?: readonly ContentPart[];
        model?: string;
        usage?: Record<string, JsonValue>;
        cost?: number;
        error?: string;
        metadata?: Record<string, JsonValue>;
    }): TreeResult<TreeNode>;
    /**
     * Move the cursor to an existing node (root-to-node path replay). Old
     * branches remain intact; the next append forks from the target.
     * @param target - target node id, or null to reset before any node.
     * @returns the new cursor and the reconstructed root-to-cursor messages.
     */
    jump(target: string | null): TreeResult<JumpView>;
    /**
     * Fork the active cursor from a historical node. This is the Pi `/fork`
     * primitive: old nodes remain intact and the next tree append becomes a child.
     * The owning service selects the matching Harness model surface path.
     */
    fork(target: string, branch?: string): TreeResult<{
        cursor: string;
        branch: string;
        forkCount: number;
    }>;
    /**
     * Set the branch label the next append joins and park the cursor at the
     * chosen node, without appending anything.
     * @param target - node to branch from (must exist).
     * @param branch - new branch label (non-empty).
     * @returns the new cursor and branch.
     */
    branch(target: string, branch: string): TreeResult<{
        cursor: string;
        branch: string;
    }>;
    /**
     * Branch with a summary of the abandoned path: park the cursor at `target`
     * (like {@link branch}), then append a summary node whose parent is the
     * target. The abandoned branch's nodes stay untouched.
     * @param target - node to branch from.
     * @param summary - summary text stored on the new node.
     * @returns the created summary node.
     */
    branchWithSummary(target: string, summary: string): TreeResult<TreeNode>;
    /**
     * Reconstruct the standard LLM messages array for the path root→node
     * (defaults to the cursor). System/user/assistant/tool messages keep their
     * roles; branch-summary nodes carry no message and stay out of the array.
     * @param from - target node id, or null for the empty path.
     * @returns messages in conversation order (root first).
     */
    messages(from?: string | null): LlmMessage[];
    /**
     * @returns all nodes in creation order (defensive copies).
     */
    log(fromSeq?: number): SessionTreeLogEntry[];
    replay(records: readonly SessionTreeLogEntry[]): TreeResult<{
        applied: number;
    }>;
    list(): TreeNode[];
    /**
     * @returns named branch pointers and their reachable nodes. Branch identity
     * comes from the session-level head map; node.branch is display metadata only.
     */
    branches(): BranchView[];
    /** Return a compact Pi-style session status projection. */
    info(): SessionTreeSessionInfo;
    /** @returns the full read view served to the browser panel. */
    view(): SessionTreeView;
    /** @returns a versioned durable snapshot (defensive copy). */
    snapshot(): SessionTreeSnapshot;
    /** Return the current leaf's root-to-leaf node path. */
    currentPath(from?: string | null): TreeNode[];
    /** Return the greatest native Session event seq already projected into this tree. */
    lastSessionEventSeq(): number;
    /** Advance the native Session event watermark after a successful sync/write. */
    markSessionEventSeq(seq: number): void;
    /** Rewind the watermark when a persisted native tail is shorter than the sidecar expected. */
    limitSessionEventSeq(seq: number): void;
    /** @returns true when a node with this id exists. */
    has(nodeId: string): boolean;
    /**
     * Find the dedicated tool-call node carrying this call id. Assistant
     * message nodes may echo the same tool-call block in their content, but a
     * tool result must never fold into them: only `type === 'tool_call'` nodes
     * represent the interaction entry the panel renders.
     */
    findToolCallNode(callId: string): TreeNode | undefined;
    /**
     * Replace a projected tool-call node with its result-merged form, so one
     * call and its result stay one tree entry even when the result arrives in a
     * later sync batch than the call. The tree is a deterministic projection of
     * the durable Session log, so this derived update never rewrites history in
     * the log itself and replays identically from scratch.
     */
    attachToolResult(callId: string, merged: TreeNode): TreeResult<TreeNode>;
    /** @returns direct child ids, used to expose the derived fork count. */
    private directChildren;
    private messagesFrom;
}
/** Keyed store: many independent trees coexist, one per session. */
export declare class SessionTreeStore {
    private readonly trees;
    /** Look up a tree without creating one. */
    get(sessionId: SessionId): SessionTree | undefined;
    /** Look up a tree, or return the standard SESSION_NOT_FOUND error. */
    require(sessionId: SessionId): TreeResult<SessionTree>;
    /** Create a new tree session. Existing ids are never silently reset. */
    create(sessionId: SessionId): SessionTree;
    /** Clone the active branch into an independent session with fresh node ids. */
    clone(sourceSessionId: SessionId, targetSessionId: SessionId): TreeResult<{
        sessionId: string;
    }>;
    /** Replace one session's tree from a previously validated candidate. */
    replace(sessionId: SessionId, tree: SessionTree): void;
    /** Replace one session's tree from a snapshot. */
    load(snapshot: SessionTreeSnapshot): TreeResult<{
        sessionId: string;
    }>;
    /** @returns all session ids with a live tree, in creation order. */
    list(): string[];
}
export type { BranchView, ContentPart, JumpView, LlmMessage, SessionTreeLogEntry, SessionTreeSessionInfo, SessionTreeSnapshot, SessionTreeView, TreeEntryType, TreeNode, TreeResult };
/**
 * Process-wide store shared by the domain service and the tool/command
 * companion, so model appends and browser jumps read the same trees.
 */
export declare const sessionTreeStore: SessionTreeStore;
