/**
 * Session-tree domain service: the append-only multi-branch conversation
 * tree, one per agent session, served to the browser through the generated
 * `sessionTree` Remote namespace.
 *
 * Design notes
 * - A process-wide store keeps every session's tree; the companion
 *   `@robiteame/dsh-tool-session-tree` plugin shares the same store, so
 *   anything the model appends is immediately visible to the browser panel
 *   and vice versa.
 * - Harness Session events are the durable source of truth; the process-wide
 *   store is an incrementally synchronized projection, while explicit snapshots
 *   remain available for export and full-tree restore.
 * - Every operation answers `{ok, value}|{ok:false,error}` from the domain
 *   layer; the Remote boundary adds its own transport envelope.
 *
 * @module @robiteame/dsh-pi-agent-session-tree
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Session } from '@deepseek-ai/dsh-session';
import type { SessionEvent, SessionEventMap } from '@deepseek-ai/dsh-session/types';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { SessionTree } from './session-tree.ts';
import type { JumpView, SessionTreeForkView, SessionTreeSessionInfo, SessionTreeView, TreeNode } from './types.ts';
export { SessionTree, SessionTreeStore, sessionTreeStore } from './session-tree.ts';
export type * from './types.ts';
export { attachToolResult, isInjectedUserNode, isInjectedUserSource, sessionEventsToTreeNodes, toolResultOf, type ProjectedToolResult } from './session-event-adapter.ts';
export { getSessionTreeSidecar, persistSessionTree, setSessionTreeSidecar, SessionTreeSidecar } from './session-tree-sidecar.ts';
export { isSessionTreeRestoreEvent, sessionTreeMarkerOf, type SessionTreeRestoreMarker } from './session-tree-marker.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        sessionTree: SessionTreeService;
    }
}
/** Selected-message-surface API added by the repository's optional dev/session-branch-surface.patch. */
interface SelectedMessageSurfaceSession {
    selectMessageSurface(nodes: readonly number[] | null): void;
    messageSurfaceNodes(): readonly number[];
}
/**
 * Whether a live Session exposes the selected-message-surface API shipped by
 * this repository's `dev/session-branch-surface.patch`. A stock DeepSeek-Harness
 * install (the target of `dsh plugin add`) has no such API: `deriveMessages()`
 * always walks the canonical surface, and unknown `session-tree/*` events
 * cannot be marked `ignorable` through the public append API, so a profile
 * cannot persist them. The tree remains fully browsable and branchable inside
 * the process store in that mode; only the in-place model-surface switch is
 * unavailable.
 */
export declare function supportsSelectedMessageSurface(session: Session): session is Session & SelectedMessageSurfaceSession;
/** How cursor movements reach the model-visible Session surface on this build. */
export type SessionTreeSurfaceMode = 'native' | 'stock' | 'projection';
/**
 * The active surface mode for one session:
 * - `native` — `dev/session-branch-surface.patch` (or an upstream merge)
 *   provides `Session.selectMessageSurface()`; jump/fork switch the model
 *   history directly.
 * - `stock` — official Harness: the plugin emulates the switch with an official
 *   empty `replace` surface event plus the durable sidecar.
 * - `projection` — the live surface is not writable in this revision;
 *   navigation updates the tree projection and panel only.
 */
export declare function sessionTreeSurfaceMode(session: Session): SessionTreeSurfaceMode;
/**
 * Whether the running Harness recognizes the durable `session-tree/*` event
 * vocabulary. The event names are registered in the session known-event-types
 * table by `dev/session-branch-surface.patch`; on stock packages an appended
 * unknown event would make a resumed persisted log unreadable, so callers must
 * skip those appends.
 */
export declare function supportsDurableSessionTreeEvents(session: Session): boolean;
/** Durable SessionTree event types appended to the owning Session log. */
export type SessionTreeEventType = 'session-tree/node' | 'session-tree/cursor' | 'session-tree/branch' | 'session-tree/selection' | 'session-tree/snapshot';
/**
 * Append one durable SessionTree marker when the runtime supports it, and
 * return undefined on stock Harness so callers can skip sequence tracking.
 */
export declare function appendSessionTreeEvent(session: Session, type: SessionTreeEventType, data: SessionEventMap[SessionTreeEventType]): SessionEvent<SessionTreeEventType> | undefined;
/**
 * Build a fresh-session seed from only the selected root-to-node path.
 *
 * The source Session is read through its immutable event snapshot; no append,
 * cursor, or surface method is called. Structural events keep copied turns
 * replayable, while events from sibling branches and messages after the
 * selected user prompt are deliberately omitted. Sequence numbers are rebuilt
 * contiguously because Agent creation requires a valid independent log.
 */
export declare function sessionPathForkSeed(source: Session, path: readonly TreeNode[]): readonly SessionEvent[];
/** Optional side-effect controls for callers that only need to inspect history. */
export interface SyncSessionTreeOptions {
    /** Apply the tree cursor to the model-visible Session surface (default true). */
    readonly applySurface?: boolean;
    /** Persist the projected tree sidecar (default true). */
    readonly persist?: boolean;
}
/** Materialize and incrementally synchronize native Harness history. */
export declare function syncSessionTree(agent: Agent, options?: SyncSessionTreeOptions): SessionTree;
/** Apply the selected tree path to Harness' actual model-visible Session surface. */
export declare function applyTreeCursorToSession(agent: Agent, tree: SessionTree): void;
/** Remote-only service backing the browser tree panel. */
export declare class SessionTreeService extends TypertRemoteService {
    /**
     * Remote methods receive an `agentId` and resolve it through `ctx.agents`.
     * Declare the dependency so the lookup runs in this plugin's own fiber.
     */
    static inject: string[];
    /**
     * Register the service under `sessionTree`.
     * @param ctx - owning Cordis Context.
     */
    constructor(ctx: Context);
    /**
     * Read the current tree view (nodes, branches, cursor) for one agent.
     * The tree is created on first read, so an empty panel is valid.
     * @param agent - owning live agent.
     * @returns the complete view for the panel.
     */
    list(agent: Agent): SessionTreeView;
    /** Synchronize native history, falling back to the last committed tree when replay fails. */
    private synced;
    /** Read the projected tree without mutating the source Session surface. */
    private readOnlyTree;
    /**
     * Move the SessionTree cursor to an existing node and return its root-to-node
     * path through the context operation. This also selects the same path on
     * Harness' model-visible Session surface, so the next turn genuinely branches
     * from this leaf instead of merely changing the browser projection.
     * @param agent - owning live agent.
     * @param nodeId - target node, or null to reset before the first node.
     * @returns the new cursor and reconstructed messages.
     * @throws Error when the node does not exist (settles as the standard error envelope).
     */
    jump(agent: Agent, nodeId: string | null): JumpView;
    /**
     * Position a named branch at a historical node for the next append.
     * @param agent - owning live agent.
     * @param nodeId - historical node to branch from.
     * @param branch - non-empty branch label.
     * @returns the parked cursor, branch label, and direct-child fork count.
     */
    fork(agent: Agent, nodeId: string, branch: string): {
        cursor: string;
        branch: string;
        forkCount: number;
    };
    /**
     * Copy only the selected user-node root path into a brand-new Session.
     * @param agent - owning live source agent.
     * @param nodeId - selected user-message node.
     * @param branch - branch label installed on the independent copy.
     * @returns the source fork point plus target session and editable prompt.
     */
    forkSession(agent: Agent, nodeId: string, branch: string): Promise<SessionTreeForkView>;
    /**
     * Legacy in-tree branch primitive retained for API compatibility. Prefer
     * {@link fork} in user-facing flows: it creates an isolated Session copy.
     */
    branchInPlace(agent: Agent, nodeId: string, branch: string): {
        cursor: string;
        branch: string;
        forkCount: number;
    };
    /**
     * Read compact status metadata for the current session tree.
     * @param agent - owning live agent.
     * @returns current tree counts, cursor, branches, and usage metadata.
     */
    session(agent: Agent): SessionTreeSessionInfo;
}
export default SessionTreeService;
