/**
 * Model-facing tool and slash-command companion of the session-tree service:
 * the `session_tree` tool, the `/tree` command family, and a system-prompt
 * section. All state lives in the shared `sessionTreeStore` from
 * `@robiteame/dsh-pi-agent-session-tree`, so the model, the command line,
 * and the browser panel observe the same trees.
 *
 * Design notes
 * - Harness Session events remain the durable history source. The prompt tells
 *   the model to read the active branch with `context`, never duplicate native
 *   turns with `append`, and never edit historical nodes.
 * - Every operation returns the standard `{ok, value}|{ok:false,error}` JSON
 *   envelope; a thrown body also settles as that envelope, so tool results
 *   are always lossless JSON.
 *
 * @module @robiteame/dsh-tool-session-tree
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-session-tree";
export declare const inject: string[];
/** System-prompt fragment steering the agent to the tree as its only history. */
export declare const SESSION_TREE_PROMPT = "SessionTree is the append-only projection of this agent's durable Harness Session log. Native user, assistant, tool, and model-context events are synchronized automatically: never duplicate ordinary turns with operation 'append'. Before answering after navigation, call session_tree with operation 'context' and treat its root-to-cursor messages as the active branch context. Use 'append' only for an explicit custom tree entry not already recorded by Harness. To explore an alternative, call 'fork' or 'branch' with a historical nodeId and branch name (or 'branch.summary' to record a summary); old nodes are never modified or deleted. Use 'branches' and 'tree' to inspect topology, and 'snapshot.save'/'snapshot.load' for explicit export or full-tree restore. All operations report failures as {ok:false,error:{code,message}}. Depending on the Harness build, jump/fork switch the model-visible history either through the native selected-surface API or through an official replace-surface emulation; when neither is available the tree is projection-only. The surface field reported by 'context' and 'session' states the active mode: native, stock, or projection.";
/** Register the tool, the command family, and the prompt section. */
export declare function apply(ctx: Context): void;
