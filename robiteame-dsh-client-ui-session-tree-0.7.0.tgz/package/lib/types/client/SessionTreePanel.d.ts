import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionTreeViewProps } from './slots.ts';
export declare function SessionTreePanel(props: SessionTreeViewProps & PropsLocale<'session-tree'>): import("react").JSX.Element;
export declare function SessionTreeDock(props: SessionTreeViewProps & PropsLocale<'session-tree'>): import("react").JSX.Element;
