/**
 * UI-layer fork-lineage annotations for the inline session-list menus.
 *
 * The fork itself — and the durable parent linkage — always comes from the
 * official native session fork API: `ctx.sessions.fork()` writes the child into
 * the reactive Session list with `parentId`, and the menus read that state for
 * topology and live updates. This registry stores only the presentation
 * metadata that state cannot know: which children were created by THIS
 * plugin's `/fork` flows (so `/clone` children and host-sidebar forks keep
 * their original display) and the short summary shown on the branch node.
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** One recorded `/fork` branch: display annotation plus its creation facts. */
export interface ForkLineageEntry {
    readonly childId: SessionId;
    readonly parentId: SessionId;
    /** Short single-line menu title (the user prompt before the selected node). */
    readonly summary?: string;
    /** Branch label supplied by remote forks, when the creator named one. */
    readonly branch?: string;
    /** Wall-clock creation time, used for stable child ordering. */
    readonly createdAt: number;
}
/** Annotation input for {@link SessionForkLineage.record}. */
export type ForkLineageRecordInput = Omit<ForkLineageEntry, 'createdAt'> & {
    createdAt?: number;
};
/** Minimal persistence face (DOM localStorage in the browser, fakes in tests). */
export interface ForkLineageStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
}
/** Storage key the browser persistence writes under (exported for tests). */
export declare const FORK_LINEAGE_STORAGE_KEY = "session-tree.forkLineage.v1";
/** Collapse a fork title prompt into one short single-line menu title. */
export declare function summarizeForkPrompt(text: string, maxLength?: number): string;
/**
 * Insertion-ordered registry of `/fork` branches. The snapshot handed to
 * React is replaced (not mutated) on every record, so `useSyncExternalStore`
 * sees a new identity exactly when the lineage changed.
 */
export declare class SessionForkLineage {
    private readonly storage;
    private snapshot;
    private readonly listeners;
    constructor(storage?: ForkLineageStorage);
    /** Stable store snapshot for `useSyncExternalStore`; identity changes on record only. */
    readonly getSnapshot: () => ReadonlyMap<SessionId, ForkLineageEntry>;
    readonly subscribe: (listener: () => void) => (() => void);
    /** Record (or re-annotate) one `/fork` child and notify menu subscribers. */
    record(input: ForkLineageRecordInput): ForkLineageEntry;
    /** Drop all annotations (test/teardown face; display is re-derived from state). */
    clear(): void;
    dispose(): void;
    private persist;
}
/** Resolve the browser localStorage lazily, staying inert outside the DOM. */
export declare function browserForkLineageStorage(): ForkLineageStorage | undefined;
