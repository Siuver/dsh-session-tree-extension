import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { JumpView, SessionTreeForkView, SessionTreeView, TreeNode } from '@robiteame/dsh-pi-agent-session-tree/client';
import type { SessionForkLineage } from './fork-lineage.ts';
export interface SessionTreeOverlayState {
    open: boolean;
    nativePanel: boolean;
    /** Added in the fork selector release; omitted by legacy state producers. */
    selectorOpen?: boolean;
    /** Added in the fork prompt editor release; omitted by legacy state producers. */
    promptDraft?: {
        sessionId: SessionId;
        text: string;
        sending: boolean;
        error: string | null;
    } | null;
}
interface SessionTreeOverlaySnapshot {
    open: boolean;
    nativePanel: boolean;
    selectorOpen: boolean;
    promptDraft: {
        sessionId: SessionId;
        text: string;
        sending: boolean;
        error: string | null;
    } | null;
}
/** Minimal external store shared by the command listener and the React drawer. */
export declare class SessionTreeOverlayController {
    private state;
    private readonly listeners;
    readonly getSnapshot: () => SessionTreeOverlaySnapshot;
    readonly subscribe: (listener: () => void) => (() => void);
    open(): void;
    close(): void;
    openSelector(): void;
    closeSelector(): void;
    openPromptDraft(sessionId: SessionId, text: string): void;
    updatePromptDraft(text: string): void;
    setPromptSending(sending: boolean, error?: string | null): void;
    clearPromptDraft(): void;
    setNativePanel(nativePanel: boolean): void;
    dispose(): void;
    private update;
}
export interface SessionTreeRemoteActions {
    load(sessionId: SessionId): Promise<SessionTreeView>;
    jump(sessionId: SessionId, nodeId: string | null): Promise<JumpView>;
    fork(sessionId: SessionId, nodeId: string, branch: string): Promise<SessionTreeForkView>;
    onRefresh(sessionId: SessionId, callback: () => void): () => void;
}
export type SessionTreeOverlayProps = PropsRuntime<'shell.overlay'> & PropsLocale<'session-tree'> & {
    controller: SessionTreeOverlayController;
    remoteActions: SessionTreeRemoteActions;
    completeFork?: (result: SessionTreeForkView) => void;
    forkUserPrompt?: (sessionId: SessionId, node: TreeNode) => Promise<void>;
    openSession?: (sessionId: SessionId) => void;
    sendPrompt?: (sessionId: SessionId, text: string) => Promise<void>;
    /** /fork annotation registry feeding the panel's worktree branch section. */
    lineage?: SessionForkLineage;
};
/**
 * Render an additive right-side drawer without replacing Harness' Tool details
 * occupant. The root stays mounted as a browser-visible activation marker;
 * only the drawer opts back into pointer events.
 */
export declare function SessionTreeOverlay({ controller, remoteActions, completeFork, forkUserPrompt, openSession, sendPrompt, lineage, useSessions, t, }: SessionTreeOverlayProps): import("react").JSX.Element;
export {};
