import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** Read the main-view selection across current and 0.2 Session-list shapes. */
export declare function currentSessionId(state: SessionListState): SessionId | undefined;
