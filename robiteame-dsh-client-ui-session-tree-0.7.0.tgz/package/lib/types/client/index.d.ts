/** Browser half of the session-tree extension: a right-details-sidebar panel. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { CommandResult } from '@deepseek-ai/dsh-commands/types';
declare module '@deepseek-ai/cordis' {
    interface Events {
        'command/executed'(sessionId: SessionId, name: string, result: CommandResult): void;
    }
}
import type { SessionTreeView } from '@robiteame/dsh-pi-agent-session-tree/client';
import { type SessionTreeKey } from './locales.ts';
export { SessionTreePanel, SessionTreeDock } from './SessionTreePanel.tsx';
export { SessionTreeOverlay, SessionTreeOverlayController } from './SessionTreeOverlay.tsx';
export type { SessionTreeOverlayProps, SessionTreeOverlayState } from './SessionTreeOverlay.tsx';
export { SessionBranchList } from './SessionBranchList.tsx';
export { buildBranchTreeModel, buildSessionGraphModel, visibleBranchRows } from './session-graph.ts';
export type { BranchTreeBadge, BranchTreeListState, BranchTreeModel, BranchTreeRow, SessionGraphBadge, SessionGraphModel, SessionGraphPlaceholder, SessionGraphRow, } from './session-graph.ts';
export { SessionForkLineage, summarizeForkPrompt } from './fork-lineage.ts';
export type { SessionBranchListProps } from './SessionBranchList.tsx';
export type { ForkLineageEntry, ForkLineageRecordInput, ForkLineageStorage } from './fork-lineage.ts';
export type { SessionTreePanelActions, SessionTreeViewProps } from './slots.ts';
export type { SessionTreeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'session-tree': SessionTreeKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
export type LoadedSessionTreeView = SessionTreeView;
