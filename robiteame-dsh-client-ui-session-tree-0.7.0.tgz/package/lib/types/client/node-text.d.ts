import type { TreeNode } from '@robiteame/dsh-pi-agent-session-tree/client';
/**
 * Browser-side twin of the host adapter's `isInjectedUserSource` (the client
 * outlet is type-only, so the five-line predicate is duplicated here). A
 * `user/message` source with an object shape whose `kind` is not `'user'`
 * marks harness-injected context — skill prompts, system-prompt snapshots,
 * context notices — rather than a typed human prompt.
 */
export declare function isInjectedUserSource(source: unknown): boolean;
/** Whether one tree node records harness-injected context instead of a typed human prompt. */
export declare function isInjectedUserNode(node: TreeNode): boolean;
/** Resolve the complete user-visible text for one session-tree node. */
export declare function nodeFullText(node: TreeNode): string;
