/**
 * Read-only projection of a Session lineage into one merged node graph.
 *
 * Session-level topology comes from the native Session list. Node-level
 * topology comes from each Session's own tree view. Native forks copy the
 * source log prefix with event sequence numbers intact, so the deepest shared
 * root-path prefix is the fork anchor. Only that prefix is deduplicated; every
 * branch-specific node keeps a session-qualified identity.
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionTreeView, TreeNode } from '@robiteame/dsh-pi-agent-session-tree/client';
import type { ForkLineageEntry } from './fork-lineage.ts';
/** Which kind of Session a row represents. */
export type BranchTreeBadge = 'main' | 'fork' | 'clone';
/** One Session in the derived lineage. */
export interface BranchTreeRow {
    readonly sessionId: SessionId;
    readonly parentId: SessionId | undefined;
    readonly title: string;
    /** 0 is the trunk root; each nesting level adds one. */
    readonly depth: number;
    /** Last sibling stops the parent rail below its elbow. */
    readonly isLast: boolean;
    /** Per ancestor level above the parent: whether its rail continues below. */
    readonly railContinues: readonly boolean[];
    readonly childCount: number;
    readonly running: boolean;
    /** The Session the UI currently has open. */
    readonly current: boolean;
    /** On the root-to-current chain. */
    readonly onActivePath: boolean;
    readonly badge: BranchTreeBadge;
    readonly branchLabel: string | undefined;
}
/** Derived Session-level lineage in DFS pre-order. */
export interface BranchTreeModel {
    readonly rows: readonly BranchTreeRow[];
    readonly rootId: SessionId;
    readonly highlightedId: SessionId;
    readonly activeAncestors: ReadonlySet<SessionId>;
}
/** Read-only projection input shared by the graph builder and tests. */
export interface BranchTreeListState {
    readonly ids?: readonly SessionId[];
    readonly byId?: Readonly<Record<SessionId, unknown>> | undefined;
    readonly current?: SessionId | undefined;
}
/** One badge rendered where a Session branch starts. */
export interface SessionGraphBadge {
    readonly sessionId: SessionId;
    readonly kind: BranchTreeBadge;
    readonly branchLabel: string | undefined;
    readonly title: string;
    readonly running: boolean;
    readonly current: boolean;
    /** Stable identity for independently collapsing this Session branch. */
    readonly collapseKey: string;
    /** Whether collapsing this badge can hide at least one branch-owned row. */
    readonly hasChildren: boolean;
}
/** Why a Session has a synthetic placeholder row instead of its nodes. */
export type SessionGraphPlaceholder = 'loading' | 'error' | 'empty';
/** One render-ready node row in the merged graph. */
export interface SessionGraphRow {
    /** Session-qualified key for unique nodes; the shared key for a copied prefix. */
    readonly key: string;
    readonly parentKey: string | null;
    readonly node: TreeNode;
    readonly owners: readonly SessionId[];
    readonly badges: readonly SessionGraphBadge[];
    readonly lane: number;
    readonly parentLane: number | null;
    readonly continues: readonly number[];
    readonly hasChildren: boolean;
    /** Branch-owned rows hidden by this row's branch collapse keys. */
    readonly branchKeys: readonly string[];
    /** The current Session's selected node. */
    readonly active: boolean;
    /** On the current Session's selected-node path. */
    readonly onActivePath: boolean;
    readonly placeholder: SessionGraphPlaceholder | undefined;
}
/** Complete merged graph plus the keys needed for reveal-on-open behavior. */
export interface SessionGraphModel {
    readonly rows: readonly SessionGraphRow[];
    readonly sessionIds: readonly SessionId[];
    readonly failedSessionIds: readonly SessionId[];
    readonly highlightedId: SessionId;
    readonly activePathKeys: ReadonlySet<string>;
    readonly activeBranchKeys: ReadonlySet<string>;
}
/**
 * Flatten one Session lineage into ordered worktree rows. The trunk is the
 * oldest ancestor of `sessionId` still present in the live list; children
 * nest under their parent ordered by creation, then list order. Cycles and
 * missing rows are skipped, never followed.
 */
export declare function buildBranchTreeModel(sessionId: SessionId, state: BranchTreeListState, entries: ReadonlyMap<SessionId, ForkLineageEntry>): BranchTreeModel | null;
/** Pre-order rows minus the descendants of collapsed rows. */
export declare function visibleBranchRows(rows: readonly BranchTreeRow[], collapsed: ReadonlySet<SessionId>): BranchTreeRow[];
/**
 * Merge every available Session view into one tree. The first Session row is
 * the trunk. Each child reconnects to the deepest matching root-path prefix
 * on its Session parent; that matched node is the fork point. A child whose
 * view is unavailable contributes one placeholder row and never fails the
 * rest of the graph.
 */
export declare function buildSessionGraphModel(topology: BranchTreeModel, views: ReadonlyMap<SessionId, SessionTreeView>, failed: ReadonlySet<SessionId>): SessionGraphModel;
