/** Native 0.2 right-Sidebar page body for the session tree. */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionTreePanelActions } from './slots.ts';
export type SessionTreeSidebarTabProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsLocale<'session-tree'> & InjectFace<SessionTreePanelActions>;
/**
 * Bind one right-Sidebar tab to the session it was opened in.
 * @param props - framework tab identity plus the session-tree action face.
 * @returns the same tree surface used by the legacy details dock.
 */
export declare function SessionTreeSidebarTab({ useTabInfo, sessionId, useSessions, t, load, jump, jumpSession, select, fork, forkUserPrompt, modeController, onRefresh, lineage, openSession, }: SessionTreeSidebarTabProps): import("react").JSX.Element;
