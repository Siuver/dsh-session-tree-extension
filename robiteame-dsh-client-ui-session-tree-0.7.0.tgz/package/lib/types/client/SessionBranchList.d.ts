import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionForkLineage } from './fork-lineage.ts';
export type SessionBranchListProps = PropsRuntime<'shell.overlay'> & PropsLocale<'session-tree'> & {
    /** /fork annotation registry shared with the fork completion wiring. */
    lineage: SessionForkLineage;
    /** Open one Session through the official Session Controller. */
    openSession: (sessionId: SessionId) => void;
};
/**
 * Portal inline /fork menus into the native session list. The component
 * renders no root DOM of its own; it keeps observers and hooks mounted while
 * no branches exist so the first fork appears without a refresh.
 */
export declare function SessionBranchList({ lineage, openSession, useSessions, t, }: SessionBranchListProps): import("react").JSX.Element | null;
